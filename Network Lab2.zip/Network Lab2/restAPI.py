from flask import Flask, session, request, jsonify
from flask_session import Session
from tempfile import mkdtemp
from functools import wraps

'''

I defined a scenario where users are using social media. 
Simple message board with users and messages (or something like twitter?)
They are users in the app and simple restAPI calls defined are GET(get all users, user info and their tweet),
POST(users can post a new tweet), DELETE(delete the first tweet of their post)

'''

app = Flask(__name__)

@app.route('/')
def welcome():
    return "Welcome"


user_1 = {'username': 'admin', 'password': 'admin'}
user_2 = {'username': 'restAPI', 'password': 'restAPI'}
users = [user_1, user_2]

tweets = [{'restAPI': 'welcome!'}]
@app.route("/restAPI/login", methods=["POST"])
def login():

    session.clear()

    if request.method == "POST":

        if not request.form.get("username"):
            return "must provide username"

        elif not request.form.get("password"):
            return "must provide password"

        user_id = -1
        for index, user in enumerate(users):
            for username, password in user.items():
                if request.form.get(
                        "username") == username and request.form.get(
                            "password") == password:
                    user_id = index

        session["user_id"] = user_id

        return 'verification success'


@app.route('/restAPI/users/<username>', methods=["GET"])
def get_user(username):
    print(request.headers)
    username_list = [user['username'] for user in users]

    username_index = -1
    try:
        username_index = username_list.index(username)
    except:
        return 'no user found'

    user_tweets = [tweet for tweet in tweets if username in tweet.keys()]

    if request.headers['Accept'] == 'text/text':
        output = ""
        output += f"User {username} has {len(user_tweets)} tweets\n"
        output += "Tweets:\n"

        for user_tweet in user_tweets:
            output += f'{username}: {user_tweet[username]}\n'

        return output

    else:
        return jsonify([{
            'username': username,
            'tweet_count': len(user_tweets)
        }, user_tweets])

@app.route('/restAPI/users', methods=["GET"])
def get_users():
    return jsonify([{
        f'user_{index}': user['username']
    } for index, user in enumerate(users)])


@app.route('/restAPI/tweets', methods=["GET", "POST"])

def get_tweets():
    if request.method == "GET":
        return jsonify([{'tweet_count': len(tweets)}, tweets])

    elif request.method == "POST":
        if not request.form.get("tweet"):
            return "must provide tweet"

        user_id = session["user_id"]
        username = users[user_id]['username']

        tweet = {username: request.form.get("tweet")}
        tweets.append(tweet)

        return jsonify(tweet)

    return 'error'


@app.route('/restAPI/tweets/<tweet_index>', methods=["GET", "DELETE"])

def get_tweet(tweet_index):
    if request.method == "GET":
        return jsonify(tweets[int(tweet_index)])

    elif request.method == "DELETE":
        user_id = session["user_id"]
        username = users[user_id]['username']

        tweet = -1
        try:
            tweet = tweets[int(tweet_index)]
            if username not in tweet.keys():
                return 'no permission'

            tweets.pop(int(tweet_index))
        except IndexError:
            return 'tweet not found'

        return jsonify(tweet)

    return 'error'



app.config["SESSION_FILE_DIR"] = mkdtemp()
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

if __name__ == "__main__":
    app.run(debug=True)