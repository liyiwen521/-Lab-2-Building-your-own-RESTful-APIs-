
# welcome message
curl http://127.0.0.1:5000/

# get all users
curl -X GET 127.0.0.1:5000/restAPI/users --output -

# get one users' info 
curl -X GET 127.0.0.1:5000/restAPI/users/restAPI --output -

# get user admin's info
curl -X GET 127.0.0.1:5000/restAPI/users/admin --output -

# user authentication
curl -X POST 127.0.0.1:5000/restAPI/login -F 'username=restAPI' -F 'password=restAPI' -b cookie_yiwen.txt -c cookie_yiwen.txt --output -

# get all tweets
curl -X GET 127.0.0.1:5000/restAPI/tweets -b cookie_yiwen.txt -c cookie_yiwen.txt --output -

# get first tweet
curl -X GET 127.0.0.1:5000/restAPI/tweets/0 -b cookie_yiwen.txt -c cookie_yiwen.txt --output -

# post new tweet 
curl -X POST 127.0.0.1:5000/restAPI/tweets -F 'tweet=A new tweet' -b cookie_yiwen.txt -c cookie_yiwen.txt --output -

# delete first tweet
curl -X DELETE 127.0.0.1:5000/restAPI/tweets/0 -b cookie_yiwen.txt -c cookie_yiwen.txt --output -